#!/bin/bash
# bashandperl.sh

echo "Greetings from the Bash part of the script."
# More Bash commands may follow here.

exit 0
# End of Bash part of the script.

# =======================================================

#!/usr/bin/perl
# This part of the script must be invoked with -x option.

print "Greetings from the Perl part of the script.\n";
# More Perl commands may follow here.

# End of Perl part of the script.
