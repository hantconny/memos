package com.ternwit.common;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class SimpleXMLEditor {
	
	/**
	 * @author Cai
	 * @param inputPath
	 * @param elementName
	 * @param attributeName
	 * @param oldAttributeValue
	 * @param newAttributeValue
	 * @param outputPath
	 * @throws DocumentException
	 * @throws IOException
	 */
	public void edit(String inputPath, String elementName, String attributeName,  String oldAttributeValue, String newAttributeValue, String outputPath) throws DocumentException, IOException {
		/* if inputPath is null or empty
		 * return */
		if (StringUtils.isEmpty(inputPath)) {
			return;
		}
		/* if inputPath does not end with forward slash
		 * append a forward slash on it */
		if (!inputPath.endsWith("/")) {
			inputPath += "/";
		}
		/* if outputPath is null or empty
		 * make a directory outputXMLs under input path */
		if (StringUtils.isEmpty(outputPath)) {
			outputPath = inputPath + "outputXMLs/";
		}
		/* if outputPath does not end with a forward slash
		 * append a forward slash ont it */
		if (!outputPath.endsWith("/")) {
			outputPath += "/";
		}
		
		File dir = new File(inputPath);
		
		if (!dir.isDirectory()) {
			return;
		}
		
		/* this filter will return all files end with .hbm.xml */
		FileFilter filter = new HibernateFileFilter();
		File[] files = dir.listFiles(filter);
		
		int total = files.length;
		int processed = 0;
		int remained = total;
		
		String tempInputPath = "";
		String tempOutputPath = "";
		
		for (File file : files) {
			
			tempInputPath = inputPath + file.getName();
			Document doc = parse(tempInputPath);
			
			tempOutputPath = outputPath + file.getName();
			
			modify(doc, elementName, attributeName, oldAttributeValue, newAttributeValue, tempOutputPath);
			
			System.out.println("total: "+total+",\t processed: "+(++processed)+",\t remained: "+(--remained));
		}
		System.out.println("process completed!");
		
	}
	
	/**
	 * @author Cai
	 * @param filePath
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private Document parse(String filePath) throws DocumentException, IOException{
		SAXReader reader = new SAXReader();
		Document document = reader.read(new FileInputStream(filePath));
		return document;
	}

	/**
	 * @author Cai
	 * @param document
	 * @param elementName
	 * @param attributeName
	 * @param oldAttributeValue
	 * @param newAttributeValue
	 * @param exportPath
	 * @throws IOException
	 */
	private void modify(Document document, String elementName, String attributeName, String oldAttributeValue, String newAttributeValue, String outputPath) throws IOException {
		/* get root element */
		Element root = document.getRootElement();
		/* get required element node */
		Element element = root.element(elementName);
		/* get required attribute node */
		Attribute attribute = element.attribute(attributeName);
		
		/* if old attribute value the same as new attribute value
		 * return */
		if (!oldAttributeValue.equalsIgnoreCase(attribute.getValue())) {
			return;
		}
		
		/* set new attribute value to attribute node */
		attribute.setValue(newAttributeValue);
		
		/* declare a format */
		OutputFormat format = OutputFormat.createPrettyPrint();
		
		/* check if output directory is exist */
		File exportDir = new File(outputPath.substring(0, outputPath.lastIndexOf("/")));
		
		if (!exportDir.exists()) {
			exportDir.mkdir();
		}
		
		XMLWriter writer = new XMLWriter(new FileWriter(new File(outputPath)), format);
		writer.write(document);
		writer.close();
	}
}
