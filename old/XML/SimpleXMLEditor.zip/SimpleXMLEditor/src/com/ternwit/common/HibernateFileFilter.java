package com.ternwit.common;

import java.io.File;
import java.io.FileFilter;

public class HibernateFileFilter implements FileFilter {

	@Override
	public boolean accept(File file) {
		String fileName = file.getName().toLowerCase();
		if (fileName.endsWith(".hbm.xml")) {
			return true;
		}
		return false;
	}

}
