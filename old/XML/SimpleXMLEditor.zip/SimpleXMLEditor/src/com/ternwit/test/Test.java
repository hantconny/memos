package com.ternwit.test;

import com.ternwit.common.SimpleXMLEditor;

public class Test {

	public static void main(String[] args) throws Exception {

		String inputPath = "xmls";
		String elementName = "class";
		String attributeName = "catalog";
		String oldAttributeValue = "tms2dev";
		String newAttributeValue = "tms2th";
		String outputPath = "";

		new SimpleXMLEditor().edit(inputPath, elementName, attributeName,
				oldAttributeValue, newAttributeValue, outputPath);
	}
}
